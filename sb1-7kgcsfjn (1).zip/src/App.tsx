import React, { useState } from 'react';
import Hero from './components/Hero';
import About from './components/About';
import PropertyListings from './components/PropertyListings';
import ListingsPage from './components/ListingsPage';
import RealtorDirectory from './components/RealtorDirectory';
import SocialMedia from './components/SocialMedia';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  const [language, setLanguage] = useState<'en' | 'es'>('en');
  const [currentPage, setCurrentPage] = useState<'home' | 'listings'>('home');

  const handleLanguageChange = (lang: 'en' | 'es') => {
    setLanguage(lang);
  };

  const handleShowListings = () => {
    setCurrentPage('listings');
  };

  const handleBackToHome = () => {
    setCurrentPage('home');
  };

  if (currentPage === 'listings') {
    return (
      <div className="min-h-screen bg-white">
        <ListingsPage language={language} onBack={handleBackToHome} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Hero language={language} onLanguageChange={handleLanguageChange} onShowListings={handleShowListings} />
      <About language={language} />
      <PropertyListings language={language} onShowAllListings={handleShowListings} />
      <RealtorDirectory language={language} />
      <SocialMedia language={language} />
      <Contact language={language} />
      <Footer language={language} />
    </div>
  );
}

export default App;